import React from 'react';
import IconAddPhoto from '../../Ui/Icon/IconAddPhoto';
import IconExit from '../../Ui/Icon/IconExit';
import IconHashtag from '../../Ui/Icon/IconHashtag';
import IconAvatar from '../../Ui/Icon/IconAvatar';
import IconPic from '../../Ui/Icon/IconPic';
import Tweet from './../Tweet/Tweet';

const TweetList = () =>
{
  return (
    <div>

      <Tweet />
      <Tweet />
      <Tweet />
      <Tweet />
      <Tweet />
      
    </div>
  );
};

export default TweetList;